/**
 * This package contains the JUnit test classes that test classes in the asgn2Pizzas, asgn2Customers, asgn2Restaurant packages.
 * 
 * @author Person A and Person B
 *
 */
package asgn2Tests;